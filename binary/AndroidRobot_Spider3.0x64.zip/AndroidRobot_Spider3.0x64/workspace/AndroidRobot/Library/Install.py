#_*_ coding: iso8859_1
# Script API

from com.android.python import AndroidDriver
        
def isPromptBeforeInstall():
    sn = device[0].getSerialNumber()
    
def watcher():
    isPromptBeforeInstall()
