#_*_ coding: iso8859_1
# Script API

from com.android.python import AndroidDriver
from org.openqa.selenium import By

def test():
    device[0].call('15021809079')
    
if __name__ == '__main__':
    test()
